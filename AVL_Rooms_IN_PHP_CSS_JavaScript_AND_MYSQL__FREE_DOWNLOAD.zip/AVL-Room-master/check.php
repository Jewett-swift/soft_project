<!DOCTYPE html>
<html>
<head>
    <title>Images</title>
</head>
<body>

<img src="view.php?id=1" height="300" width="300">

</body>
</html>